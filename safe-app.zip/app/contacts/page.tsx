"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ArrowLeft, Plus, Phone, Shield, MapPin, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"

interface Contact {
  id: string
  name: string
  phone: string
  type: string
}

export default function ContactsPage() {
  const [collegeContacts, setCollegeContacts] = useState<Contact[]>([])
  const [emergencyContacts, setEmergencyContacts] = useState<Contact[]>([])
  const [personalContacts, setPersonalContacts] = useState<Contact[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [newContact, setNewContact] = useState({ name: "", phone: "", type: "personal" })
  const { toast } = useToast()

  useEffect(() => {
    async function fetchContacts() {
      try {
        const response = await fetch("/api/contacts")
        const data = await response.json()

        // Sort contacts by type
        const college: Contact[] = []
        const emergency: Contact[] = []
        const personal: Contact[] = []

        data.contacts.forEach((contact: Contact) => {
          if (contact.type === "college") {
            college.push(contact)
          } else if (contact.type === "emergency") {
            emergency.push(contact)
          } else if (contact.type === "personal") {
            personal.push(contact)
          }
        })

        setCollegeContacts(college)
        setEmergencyContacts(emergency)
        setPersonalContacts(personal)
      } catch (error) {
        console.error("Error fetching contacts:", error)
        toast({
          title: "Error",
          description: "Failed to load contacts. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchContacts()
  }, [toast])

  const handleAddContact = async () => {
    try {
      const response = await fetch("/api/contacts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newContact),
      })

      const data = await response.json()

      if (data.success) {
        toast({
          title: "Success",
          description: "Contact added successfully",
        })

        // Add the new contact to the appropriate list
        if (newContact.type === "personal") {
          setPersonalContacts([...personalContacts, data.contact])
        }

        // Reset form and close dialog
        setNewContact({ name: "", phone: "", type: "personal" })
        setIsAddDialogOpen(false)
      } else {
        throw new Error(data.error || "Failed to add contact")
      }
    } catch (error) {
      console.error("Error adding contact:", error)
      toast({
        title: "Error",
        description: "Failed to add contact. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleCall = (phone: string) => {
    window.location.href = `tel:${phone}`
  }

  return (
    <div className="flex flex-col min-h-screen bg-purple-50">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white border-b shadow-sm">
        <div className="container flex items-center h-16 px-4">
          <Link href="/" className="mr-4">
            <ArrowLeft className="w-6 h-6 text-purple-900" />
          </Link>
          <h1 className="text-xl font-bold text-purple-900">Emergency Contacts</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container px-4 py-6">
        {isLoading ? (
          <div className="flex justify-center items-center h-40">
            <p className="text-purple-600">Loading contacts...</p>
          </div>
        ) : (
          <>
            <section className="mb-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold text-purple-900">College Contacts</h2>
              </div>

              {collegeContacts.map((contact) => (
                <Card key={contact.id} className="bg-white shadow-sm border-purple-100 mb-3">
                  <CardContent className="p-4 flex items-center justify-between">
                    <div className="flex items-center">
                      <Avatar className="h-10 w-10 mr-3 bg-purple-100">
                        <AvatarFallback className="text-purple-600">{contact.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <h4 className="font-medium text-purple-900">{contact.name}</h4>
                        <p className="text-sm text-gray-600">{contact.phone}</p>
                      </div>
                    </div>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="rounded-full"
                      onClick={() => handleCall(contact.phone)}
                    >
                      <Phone className="h-5 w-5 text-purple-600" />
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </section>

            <section className="mb-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold text-purple-900">Emergency Services</h2>
              </div>

              {emergencyContacts.map((contact) => (
                <Card key={contact.id} className="bg-white shadow-sm border-purple-100 mb-3">
                  <CardContent className="p-4 flex items-center justify-between">
                    <div className="flex items-center">
                      <Avatar className="h-10 w-10 mr-3 bg-red-100">
                        <AvatarFallback className="text-red-600">{contact.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <h4 className="font-medium text-purple-900">{contact.name}</h4>
                        <p className="text-sm text-gray-600">{contact.phone}</p>
                      </div>
                    </div>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="rounded-full"
                      onClick={() => handleCall(contact.phone)}
                    >
                      <Phone className="h-5 w-5 text-purple-600" />
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </section>

            <section>
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold text-purple-900">Personal Contacts</h2>
                <Button
                  size="sm"
                  variant="outline"
                  className="flex items-center gap-1"
                  onClick={() => setIsAddDialogOpen(true)}
                >
                  <Plus className="h-4 w-4" /> Add
                </Button>
              </div>

              {personalContacts.length > 0 ? (
                personalContacts.map((contact) => (
                  <Card key={contact.id} className="bg-white shadow-sm border-purple-100 mb-3">
                    <CardContent className="p-4 flex items-center justify-between">
                      <div className="flex items-center">
                        <Avatar className="h-10 w-10 mr-3 bg-green-100">
                          <AvatarFallback className="text-green-600">{contact.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <h4 className="font-medium text-purple-900">{contact.name}</h4>
                          <p className="text-sm text-gray-600">{contact.phone}</p>
                        </div>
                      </div>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="rounded-full"
                        onClick={() => handleCall(contact.phone)}
                      >
                        <Phone className="h-5 w-5 text-purple-600" />
                      </Button>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <Card className="bg-white shadow-sm border-purple-100 mb-3">
                  <CardContent className="p-4 text-center text-gray-500">No personal contacts added yet.</CardContent>
                </Card>
              )}
            </section>
          </>
        )}
      </main>

      {/* Add Contact Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Add Emergency Contact</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="name" className="text-right">
                Name
              </Label>
              <Input
                id="name"
                value={newContact.name}
                onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="phone" className="text-right">
                Phone
              </Label>
              <Input
                id="phone"
                value={newContact.phone}
                onChange={(e) => setNewContact({ ...newContact, phone: e.target.value })}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="type" className="text-right">
                Type
              </Label>
              <Select value={newContact.type} onValueChange={(value) => setNewContact({ ...newContact, type: value })}>
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select contact type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="personal">Personal</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddContact}>Save Contact</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Navigation */}
      <nav className="sticky bottom-0 bg-white border-t shadow-sm">
        <div className="container flex items-center justify-around h-16">
          <Link href="/" className="flex flex-col items-center">
            <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
              <Shield className="w-5 h-5 text-gray-600" />
            </div>
            <span className="text-xs font-medium text-gray-600">Home</span>
          </Link>
          <Link href="/location" className="flex flex-col items-center">
            <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
              <MapPin className="w-5 h-5 text-gray-600" />
            </div>
            <span className="text-xs font-medium text-gray-600">Location</span>
          </Link>
          <Link href="/contacts" className="flex flex-col items-center">
            <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
              <Phone className="w-5 h-5 text-purple-600" />
            </div>
            <span className="text-xs font-medium text-purple-900">Contacts</span>
          </Link>
          <Link href="/resources" className="flex flex-col items-center">
            <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
              <Info className="w-5 h-5 text-gray-600" />
            </div>
            <span className="text-xs font-medium text-gray-600">Resources</span>
          </Link>
        </div>
      </nav>
    </div>
  )
}
