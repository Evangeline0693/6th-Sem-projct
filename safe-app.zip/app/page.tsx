"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Shield, MapPin, Phone, Bell, Info, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"

export default function Home() {
  const [isSendingSOS, setIsSendingSOS] = useState(false)
  const [isSOSDialogOpen, setIsSOSDialogOpen] = useState(false)
  const [countdown, setCountdown] = useState(5)
  const [location, setLocation] = useState<{ latitude: number | null; longitude: number | null }>({
    latitude: null,
    longitude: null,
  })
  const { toast } = useToast()

  useEffect(() => {
    // Get current location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords
          setLocation({ latitude, longitude })
        },
        (error) => {
          console.error("Error getting location:", error)
          toast({
            title: "Location Error",
            description: "Failed to get your location. Some features may not work properly.",
            variant: "destructive",
          })
        },
      )
    }
  }, [toast])

  useEffect(() => {
    let timer: NodeJS.Timeout

    if (isSOSDialogOpen && countdown > 0) {
      timer = setTimeout(() => setCountdown(countdown - 1), 1000)
    } else if (isSOSDialogOpen && countdown === 0) {
      handleSendSOS()
    }

    return () => {
      if (timer) clearTimeout(timer)
    }
  }, [isSOSDialogOpen, countdown])

  const handleSOSButtonClick = () => {
    setIsSOSDialogOpen(true)
    setCountdown(5)
  }

  const cancelSOS = () => {
    setIsSOSDialogOpen(false)
    setCountdown(5)
  }

  const handleSendSOS = async () => {
    setIsSendingSOS(true)
    setIsSOSDialogOpen(false)

    try {
      const response = await fetch("/api/sos", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: "current-user", // In a real app, this would be the authenticated user's ID
          latitude: location.latitude,
          longitude: location.longitude,
        }),
      })

      const data = await response.json()

      if (data.success) {
        toast({
          title: "SOS Alert Sent",
          description: "Emergency services have been notified of your situation.",
          variant: "default",
        })
      } else {
        throw new Error(data.error || "Failed to send SOS alert")
      }
    } catch (error) {
      console.error("Error sending SOS:", error)
      toast({
        title: "Error",
        description: "Failed to send SOS alert. Please try again or call emergency services directly.",
        variant: "destructive",
      })
    } finally {
      setIsSendingSOS(false)
    }
  }

  return (
    <div className="flex flex-col min-h-screen bg-purple-50">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white border-b shadow-sm">
        <div className="container flex items-center justify-between h-16 px-4">
          <div className="flex items-center gap-2">
            <Shield className="w-6 h-6 text-purple-600" />
            <h1 className="text-xl font-bold text-purple-900">Safe</h1>
          </div>
          <Link href="/profile">
            <div className="w-8 h-8 rounded-full bg-purple-200 flex items-center justify-center text-purple-700 font-semibold">
              S
            </div>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container px-4 py-6">
        {/* Welcome Section */}
        <section className="mb-8">
          <h2 className="text-2xl font-bold text-purple-900 mb-2">Welcome, Student</h2>
          <p className="text-gray-600">St. Claret Autonomous College</p>
        </section>

        {/* Emergency Button */}
        <section className="mb-8">
          <Button
            className="w-full py-8 text-xl font-bold bg-red-600 hover:bg-red-700 transition-colors"
            onClick={handleSOSButtonClick}
            disabled={isSendingSOS}
          >
            {isSendingSOS ? (
              <>
                <Loader2 className="w-6 h-6 mr-2 animate-spin" />
                Sending SOS...
              </>
            ) : (
              "Emergency SOS"
            )}
          </Button>
          <p className="text-sm text-center mt-2 text-gray-500">
            Press in case of emergency. Campus security will be alerted.
          </p>
        </section>

        {/* Quick Actions */}
        <section className="grid grid-cols-2 gap-4 mb-8">
          <Card className="bg-white shadow-sm border-purple-100">
            <CardContent className="p-4 flex flex-col items-center">
              <Link href="/location" className="flex flex-col items-center w-full">
                <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center mb-2">
                  <MapPin className="w-6 h-6 text-purple-600" />
                </div>
                <span className="text-sm font-medium text-purple-900">Share Location</span>
              </Link>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm border-purple-100">
            <CardContent className="p-4 flex flex-col items-center">
              <Link href="/contacts" className="flex flex-col items-center w-full">
                <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center mb-2">
                  <Phone className="w-6 h-6 text-purple-600" />
                </div>
                <span className="text-sm font-medium text-purple-900">Emergency Contacts</span>
              </Link>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm border-purple-100">
            <CardContent className="p-4 flex flex-col items-center">
              <Link href="/alerts" className="flex flex-col items-center w-full">
                <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center mb-2">
                  <Bell className="w-6 h-6 text-purple-600" />
                </div>
                <span className="text-sm font-medium text-purple-900">Safety Alerts</span>
              </Link>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm border-purple-100">
            <CardContent className="p-4 flex flex-col items-center">
              <Link href="/resources" className="flex flex-col items-center w-full">
                <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center mb-2">
                  <Info className="w-6 h-6 text-purple-600" />
                </div>
                <span className="text-sm font-medium text-purple-900">Safety Resources</span>
              </Link>
            </CardContent>
          </Card>
        </section>

        {/* Safety Tips */}
        <section>
          <h3 className="text-lg font-semibold text-purple-900 mb-3">Safety Tips</h3>
          <Card className="bg-white shadow-sm border-purple-100 mb-3">
            <CardContent className="p-4">
              <h4 className="font-medium text-purple-900 mb-1">Campus Buddy System</h4>
              <p className="text-sm text-gray-600">
                Always use the buddy system when walking around campus after dark.
              </p>
            </CardContent>
          </Card>
          <Card className="bg-white shadow-sm border-purple-100 mb-3">
            <CardContent className="p-4">
              <h4 className="font-medium text-purple-900 mb-1">Stay Connected</h4>
              <p className="text-sm text-gray-600">Keep your phone charged and let friends know your whereabouts.</p>
            </CardContent>
          </Card>
          <Card className="bg-white shadow-sm border-purple-100">
            <CardContent className="p-4">
              <h4 className="font-medium text-purple-900 mb-1">Emergency Numbers</h4>
              <p className="text-sm text-gray-600">
                Save campus security (555-1234) and local police (911) in your contacts.
              </p>
            </CardContent>
          </Card>
        </section>
      </main>

      {/* SOS Confirmation Dialog */}
      <Dialog open={isSOSDialogOpen} onOpenChange={setIsSOSDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle className="text-red-600">Emergency SOS Alert</DialogTitle>
            <DialogDescription>
              Sending SOS alert in {countdown} seconds. This will notify campus security and your emergency contacts.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <p className="text-center text-sm text-gray-500">Press Cancel if this was a mistake.</p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={cancelSOS}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleSendSOS}>
              Send Now
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Navigation */}
      <nav className="sticky bottom-0 bg-white border-t shadow-sm">
        <div className="container flex items-center justify-around h-16">
          <Link href="/" className="flex flex-col items-center">
            <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
              <Shield className="w-5 h-5 text-purple-600" />
            </div>
            <span className="text-xs font-medium text-purple-900">Home</span>
          </Link>
          <Link href="/location" className="flex flex-col items-center">
            <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
              <MapPin className="w-5 h-5 text-gray-600" />
            </div>
            <span className="text-xs font-medium text-gray-600">Location</span>
          </Link>
          <Link href="/contacts" className="flex flex-col items-center">
            <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
              <Phone className="w-5 h-5 text-gray-600" />
            </div>
            <span className="text-xs font-medium text-gray-600">Contacts</span>
          </Link>
          <Link href="/resources" className="flex flex-col items-center">
            <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
              <Info className="w-5 h-5 text-gray-600" />
            </div>
            <span className="text-xs font-medium text-gray-600">Resources</span>
          </Link>
        </div>
      </nav>
    </div>
  )
}
