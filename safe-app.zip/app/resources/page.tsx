import Link from "next/link"
import { ArrowLeft, FileText, ExternalLink, Shield, MapPin, Phone, Info } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export default function ResourcesPage() {
  return (
    <div className="flex flex-col min-h-screen bg-purple-50">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white border-b shadow-sm">
        <div className="container flex items-center h-16 px-4">
          <Link href="/" className="mr-4">
            <ArrowLeft className="w-6 h-6 text-purple-900" />
          </Link>
          <h1 className="text-xl font-bold text-purple-900">Safety Resources</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container px-4 py-6">
        <section className="mb-6">
          <h2 className="text-lg font-semibold text-purple-900 mb-3">College Resources</h2>

          <Card className="bg-white shadow-sm border-purple-100 mb-3">
            <CardContent className="p-4">
              <div className="flex items-start">
                <div className="mr-3 mt-1">
                  <FileText className="h-5 w-5 text-purple-600" />
                </div>
                <div>
                  <h4 className="font-medium text-purple-900 mb-1">Women's Cell</h4>
                  <p className="text-sm text-gray-600 mb-2">
                    The Women's Cell at St. Claret College provides support and resources for female students.
                  </p>
                  <Link href="#" className="text-sm text-purple-600 flex items-center">
                    Learn more <ExternalLink className="h-3 w-3 ml-1" />
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm border-purple-100 mb-3">
            <CardContent className="p-4">
              <div className="flex items-start">
                <div className="mr-3 mt-1">
                  <FileText className="h-5 w-5 text-purple-600" />
                </div>
                <div>
                  <h4 className="font-medium text-purple-900 mb-1">Campus Security Guidelines</h4>
                  <p className="text-sm text-gray-600 mb-2">
                    Learn about the security measures in place at St. Claret College.
                  </p>
                  <Link href="#" className="text-sm text-purple-600 flex items-center">
                    View guidelines <ExternalLink className="h-3 w-3 ml-1" />
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm border-purple-100">
            <CardContent className="p-4">
              <div className="flex items-start">
                <div className="mr-3 mt-1">
                  <FileText className="h-5 w-5 text-purple-600" />
                </div>
                <div>
                  <h4 className="font-medium text-purple-900 mb-1">Counseling Services</h4>
                  <p className="text-sm text-gray-600 mb-2">
                    Free and confidential counseling services are available to all students.
                  </p>
                  <Link href="#" className="text-sm text-purple-600 flex items-center">
                    Book appointment <ExternalLink className="h-3 w-3 ml-1" />
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        <section className="mb-6">
          <h2 className="text-lg font-semibold text-purple-900 mb-3">Safety Workshops</h2>

          <Card className="bg-white shadow-sm border-purple-100 mb-3">
            <CardContent className="p-4">
              <h4 className="font-medium text-purple-900 mb-1">Self-Defense Training</h4>
              <p className="text-sm text-gray-600 mb-1">Every Saturday, 10:00 AM - 12:00 PM</p>
              <p className="text-sm text-gray-600 mb-2">Sports Complex</p>
              <Link href="#" className="text-sm text-purple-600 flex items-center">
                Register <ExternalLink className="h-3 w-3 ml-1" />
              </Link>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm border-purple-100">
            <CardContent className="p-4">
              <h4 className="font-medium text-purple-900 mb-1">Digital Safety Workshop</h4>
              <p className="text-sm text-gray-600 mb-1">May 15, 2:00 PM - 4:00 PM</p>
              <p className="text-sm text-gray-600 mb-2">Computer Lab</p>
              <Link href="#" className="text-sm text-purple-600 flex items-center">
                Register <ExternalLink className="h-3 w-3 ml-1" />
              </Link>
            </CardContent>
          </Card>
        </section>

        <section>
          <h2 className="text-lg font-semibold text-purple-900 mb-3">External Resources</h2>

          <Card className="bg-white shadow-sm border-purple-100 mb-3">
            <CardContent className="p-4">
              <div className="flex items-start">
                <div className="mr-3 mt-1">
                  <FileText className="h-5 w-5 text-purple-600" />
                </div>
                <div>
                  <h4 className="font-medium text-purple-900 mb-1">National Commission for Women</h4>
                  <p className="text-sm text-gray-600 mb-2">Resources and support for women's safety and rights.</p>
                  <Link href="#" className="text-sm text-purple-600 flex items-center">
                    Visit website <ExternalLink className="h-3 w-3 ml-1" />
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm border-purple-100">
            <CardContent className="p-4">
              <div className="flex items-start">
                <div className="mr-3 mt-1">
                  <FileText className="h-5 w-5 text-purple-600" />
                </div>
                <div>
                  <h4 className="font-medium text-purple-900 mb-1">Safety Apps Guide</h4>
                  <p className="text-sm text-gray-600 mb-2">A guide to other safety apps that complement Safe.</p>
                  <Link href="#" className="text-sm text-purple-600 flex items-center">
                    Download guide <ExternalLink className="h-3 w-3 ml-1" />
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
      </main>

      {/* Navigation */}
      <nav className="sticky bottom-0 bg-white border-t shadow-sm">
        <div className="container flex items-center justify-around h-16">
          <Link href="/" className="flex flex-col items-center">
            <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
              <Shield className="w-5 h-5 text-gray-600" />
            </div>
            <span className="text-xs font-medium text-gray-600">Home</span>
          </Link>
          <Link href="/location" className="flex flex-col items-center">
            <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
              <MapPin className="w-5 h-5 text-gray-600" />
            </div>
            <span className="text-xs font-medium text-gray-600">Location</span>
          </Link>
          <Link href="/contacts" className="flex flex-col items-center">
            <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
              <Phone className="w-5 h-5 text-gray-600" />
            </div>
            <span className="text-xs font-medium text-gray-600">Contacts</span>
          </Link>
          <Link href="/resources" className="flex flex-col items-center">
            <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
              <Info className="w-5 h-5 text-purple-600" />
            </div>
            <span className="text-xs font-medium text-purple-900">Resources</span>
          </Link>
        </div>
      </nav>
    </div>
  )
}
