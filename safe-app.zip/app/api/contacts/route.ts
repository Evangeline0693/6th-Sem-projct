import { type NextRequest, NextResponse } from "next/server"
import { database } from "@/lib/firebase"
import { ref, get, push, set } from "firebase/database"

// Sample emergency contacts (fallback if database is not available)
const sampleContacts = [
  { id: "1", name: "Campus Security", phone: "555-1234", type: "college" },
  { id: "2", name: "Women's Cell", phone: "555-5678", type: "college" },
  { id: "3", name: "Health Center", phone: "555-9012", type: "college" },
  { id: "4", name: "Police", phone: "100", type: "emergency" },
  { id: "5", name: "Ambulance", phone: "108", type: "emergency" },
  { id: "6", name: "Women's Helpline", phone: "1091", type: "emergency" },
]

export async function GET() {
  try {
    // Try to get contacts from Firebase
    const contactsRef = ref(database, "contacts")
    const snapshot = await get(contactsRef)

    if (snapshot.exists()) {
      // Convert Firebase object to array
      const contactsData = snapshot.val()
      const contacts = Object.keys(contactsData).map((key) => ({
        id: key,
        ...contactsData[key],
      }))

      return NextResponse.json({ contacts })
    } else {
      // If no contacts in database, return sample contacts
      // In a real app, you might want to initialize the database with sample contacts
      return NextResponse.json({ contacts: sampleContacts })
    }
  } catch (error) {
    console.error("Error fetching contacts:", error)
    // Fallback to sample contacts if Firebase fails
    return NextResponse.json({ contacts: sampleContacts })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    // Validate contact data
    if (!data.name || !data.phone || !data.type) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Add contact to Firebase
    const contactsRef = ref(database, "contacts")
    const newContactRef = push(contactsRef)
    await set(newContactRef, {
      name: data.name,
      phone: data.phone,
      type: data.type,
    })

    return NextResponse.json({
      success: true,
      message: "Contact added successfully",
      contact: {
        id: newContactRef.key,
        ...data,
      },
    })
  } catch (error) {
    console.error("Error adding contact:", error)
    return NextResponse.json({ error: "Failed to add contact" }, { status: 500 })
  }
}
