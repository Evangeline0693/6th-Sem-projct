import { type NextRequest, NextResponse } from "next/server"
import { database } from "@/lib/firebase"
import { ref, push, set } from "firebase/database"

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    // Validate location data
    if (!data.latitude || !data.longitude) {
      return NextResponse.json({ error: "Missing latitude or longitude" }, { status: 400 })
    }

    // Get user ID from request (in a real app, this would come from authentication)
    const userId = data.userId || "anonymous"

    // Store location in Firebase
    const locationRef = ref(database, `locations/${userId}`)
    const newLocationRef = push(locationRef)
    await set(newLocationRef, {
      latitude: data.latitude,
      longitude: data.longitude,
      timestamp: Date.now(),
      sharedWith: data.sharedWith || [],
    })

    return NextResponse.json({
      success: true,
      message: "Location shared successfully",
      locationId: newLocationRef.key,
    })
  } catch (error) {
    console.error("Error sharing location:", error)
    return NextResponse.json({ error: "Failed to share location" }, { status: 500 })
  }
}
