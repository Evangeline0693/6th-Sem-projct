import { type NextRequest, NextResponse } from "next/server"
import { database } from "@/lib/firebase"
import { ref, push, set } from "firebase/database"

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    // Get user ID from request (in a real app, this would come from authentication)
    const userId = data.userId || "anonymous"

    // Store SOS alert in Firebase
    const sosRef = ref(database, "sos")
    const newSosRef = push(sosRef)
    await set(newSosRef, {
      userId,
      latitude: data.latitude,
      longitude: data.longitude,
      timestamp: Date.now(),
      status: "active",
    })

    return NextResponse.json({
      success: true,
      message: "SOS alert sent successfully",
      sosId: newSosRef.key,
    })
  } catch (error) {
    console.error("Error sending SOS alert:", error)
    return NextResponse.json({ error: "Failed to send SOS alert" }, { status: 500 })
  }
}
