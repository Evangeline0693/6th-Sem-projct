"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ArrowLeft, MapPin, Share2, Shield, Phone, Info, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/components/ui/use-toast"

interface LocationState {
  latitude: number | null
  longitude: number | null
  address: string
  isLoading: boolean
  isSharing: boolean
  error: string | null
}

interface ShareTarget {
  id: string
  name: string
  checked: boolean
}

export default function LocationPage() {
  const [location, setLocation] = useState<LocationState>({
    latitude: null,
    longitude: null,
    address: "Unknown location",
    isLoading: true,
    isSharing: false,
    error: null,
  })

  const [shareTargets, setShareTargets] = useState<ShareTarget[]>([
    { id: "campus-security", name: "Campus Security", checked: true },
    { id: "emergency-contact", name: "Emergency Contact", checked: false },
    { id: "friends", name: "Friends", checked: false },
    { id: "family", name: "Family", checked: false },
  ])

  const { toast } = useToast()

  useEffect(() => {
    // Get current location when component mounts
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords

          // In a real app, you would use a reverse geocoding service here
          // For this example, we'll just use a placeholder
          setLocation({
            latitude,
            longitude,
            address: "St. Claret Autonomous College, Main Campus",
            isLoading: false,
            isSharing: false,
            error: null,
          })
        },
        (error) => {
          console.error("Error getting location:", error)
          setLocation({
            latitude: null,
            longitude: null,
            address: "Unknown location",
            isLoading: false,
            isSharing: false,
            error: "Failed to get your location. Please enable location services.",
          })

          toast({
            title: "Location Error",
            description: "Failed to get your location. Please enable location services.",
            variant: "destructive",
          })
        },
      )
    } else {
      setLocation({
        latitude: null,
        longitude: null,
        address: "Unknown location",
        isLoading: false,
        isSharing: false,
        error: "Geolocation is not supported by your browser.",
      })

      toast({
        title: "Location Error",
        description: "Geolocation is not supported by your browser.",
        variant: "destructive",
      })
    }
  }, [toast])

  const handleShareLocation = async () => {
    if (!location.latitude || !location.longitude) {
      toast({
        title: "Error",
        description: "Cannot share location. Location data is not available.",
        variant: "destructive",
      })
      return
    }

    setLocation((prev) => ({ ...prev, isSharing: true }))

    try {
      // Get selected share targets
      const selectedTargets = shareTargets.filter((target) => target.checked).map((target) => target.id)

      if (selectedTargets.length === 0) {
        throw new Error("Please select at least one contact to share with")
      }

      const response = await fetch("/api/location", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          latitude: location.latitude,
          longitude: location.longitude,
          userId: "current-user", // In a real app, this would be the authenticated user's ID
          sharedWith: selectedTargets,
        }),
      })

      const data = await response.json()

      if (data.success) {
        toast({
          title: "Location Shared",
          description: "Your location has been shared successfully.",
        })
      } else {
        throw new Error(data.error || "Failed to share location")
      }
    } catch (error) {
      console.error("Error sharing location:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to share location",
        variant: "destructive",
      })
    } finally {
      setLocation((prev) => ({ ...prev, isSharing: false }))
    }
  }

  const toggleShareTarget = (id: string) => {
    setShareTargets((prev) =>
      prev.map((target) => (target.id === id ? { ...target, checked: !target.checked } : target)),
    )
  }

  return (
    <div className="flex flex-col min-h-screen bg-purple-50">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white border-b shadow-sm">
        <div className="container flex items-center h-16 px-4">
          <Link href="/" className="mr-4">
            <ArrowLeft className="w-6 h-6 text-purple-900" />
          </Link>
          <h1 className="text-xl font-bold text-purple-900">Share Location</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container px-4 py-6">
        {/* Map Placeholder */}
        <div className="w-full h-64 bg-gray-200 rounded-lg mb-6 flex items-center justify-center">
          {location.isLoading ? (
            <Loader2 className="w-12 h-12 text-purple-400 animate-spin" />
          ) : location.error ? (
            <div className="text-center p-4">
              <MapPin className="w-12 h-12 text-red-400 mx-auto mb-2" />
              <p className="text-red-500">{location.error}</p>
            </div>
          ) : (
            <>
              <MapPin className="w-12 h-12 text-purple-400" />
              <span className="sr-only">
                Map showing location at latitude {location.latitude} and longitude {location.longitude}
              </span>
            </>
          )}
        </div>

        <Card className="bg-white shadow-sm border-purple-100 mb-6">
          <CardContent className="p-4">
            <h3 className="font-medium text-purple-900 mb-2">Your Current Location</h3>
            <p className="text-sm text-gray-600 mb-1">{location.address}</p>
            {location.latitude && location.longitude && (
              <p className="text-xs text-gray-500 mb-4">
                Lat: {location.latitude.toFixed(6)}, Long: {location.longitude.toFixed(6)}
              </p>
            )}
            <Button
              className="w-full flex items-center justify-center gap-2 bg-purple-600 hover:bg-purple-700"
              onClick={handleShareLocation}
              disabled={location.isLoading || location.isSharing || !!location.error}
            >
              {location.isSharing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Sharing...
                </>
              ) : (
                <>
                  <Share2 className="w-4 h-4" />
                  Share My Location
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        <section className="mb-6">
          <h3 className="text-lg font-semibold text-purple-900 mb-3">Share With</h3>

          <div className="space-y-3">
            {shareTargets.map((target) => (
              <div key={target.id} className="flex items-center space-x-2">
                <Checkbox
                  id={target.id}
                  checked={target.checked}
                  onCheckedChange={() => toggleShareTarget(target.id)}
                />
                <label
                  htmlFor={target.id}
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  {target.name}
                </label>
              </div>
            ))}
          </div>
        </section>

        <section>
          <h3 className="text-lg font-semibold text-purple-900 mb-3">Location Safety</h3>

          <Card className="bg-white shadow-sm border-purple-100 mb-3">
            <CardContent className="p-4">
              <h4 className="font-medium text-purple-900 mb-1">Safe Zones</h4>
              <p className="text-sm text-gray-600">
                Library, Main Building, Cafeteria, and Hostels are monitored 24/7.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm border-purple-100">
            <CardContent className="p-4">
              <h4 className="font-medium text-purple-900 mb-1">Location Privacy</h4>
              <p className="text-sm text-gray-600">
                Your location is only shared with people you choose and is automatically deleted after 24 hours.
              </p>
            </CardContent>
          </Card>
        </section>
      </main>

      {/* Navigation */}
      <nav className="sticky bottom-0 bg-white border-t shadow-sm">
        <div className="container flex items-center justify-around h-16">
          <Link href="/" className="flex flex-col items-center">
            <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
              <Shield className="w-5 h-5 text-gray-600" />
            </div>
            <span className="text-xs font-medium text-gray-600">Home</span>
          </Link>
          <Link href="/location" className="flex flex-col items-center">
            <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
              <MapPin className="w-5 h-5 text-purple-600" />
            </div>
            <span className="text-xs font-medium text-purple-900">Location</span>
          </Link>
          <Link href="/contacts" className="flex flex-col items-center">
            <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
              <Phone className="w-5 h-5 text-gray-600" />
            </div>
            <span className="text-xs font-medium text-gray-600">Contacts</span>
          </Link>
          <Link href="/resources" className="flex flex-col items-center">
            <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
              <Info className="w-5 h-5 text-gray-600" />
            </div>
            <span className="text-xs font-medium text-gray-600">Resources</span>
          </Link>
        </div>
      </nav>
    </div>
  )
}
