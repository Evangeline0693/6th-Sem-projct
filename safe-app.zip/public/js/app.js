document.addEventListener("DOMContentLoaded", () => {
  const sign_in_btn = document.querySelector("#sign-in-btn")
  const sign_up_btn = document.querySelector("#sign-up-btn")
  const container = document.querySelector(".container")
  const passwordInput = document.querySelector('input[name="password"]')
  const passwordStrength = document.querySelector(".password-strength")
  const confirmPasswordInput = document.querySelector('input[name="confirm_password"]')
  const signUpForm = document.querySelector(".sign-up-form")
  const signInForm = document.querySelector(".sign-in-form")

  // Toggle between sign in and sign up
  sign_up_btn.addEventListener("click", () => {
    container.classList.add("sign-up-mode")
  })

  sign_in_btn.addEventListener("click", () => {
    container.classList.remove("sign-up-mode")
  })

  // Password strength checker
  if (passwordInput) {
    passwordInput.addEventListener("input", function () {
      const password = this.value
      let strength = 0

      // Check length
      if (password.length >= 8) {
        strength += 1
      }

      // Check for mixed case
      if (password.match(/[a-z]/) && password.match(/[A-Z]/)) {
        strength += 1
      }

      // Check for numbers
      if (password.match(/\d/)) {
        strength += 1
      }

      // Check for special characters
      if (password.match(/[^a-zA-Z\d]/)) {
        strength += 1
      }

      // Update strength indicator
      passwordStrength.className = "password-strength"
      if (password.length === 0) {
        passwordStrength.className = "password-strength"
      } else if (strength < 2) {
        passwordStrength.className = "password-strength weak"
      } else if (strength < 4) {
        passwordStrength.className = "password-strength medium"
      } else {
        passwordStrength.className = "password-strength strong"
      }
    })
  }

  // Form validation
  if (signUpForm) {
    signUpForm.addEventListener("submit", (e) => {
      const password = passwordInput.value
      const confirmPassword = confirmPasswordInput.value

      if (password !== confirmPassword) {
        e.preventDefault()
        alert("Passwords do not match!")
        return false
      }

      if (password.length < 8) {
        e.preventDefault()
        alert("Password must be at least 8 characters long!")
        return false
      }

      return true
    })
  }

  // Add floating label effect
  const inputs = document.querySelectorAll(".input-field input")
  inputs.forEach((input) => {
    input.addEventListener("focus", () => {
      input.parentNode.classList.add("focused")
    })

    input.addEventListener("blur", () => {
      if (input.value === "") {
        input.parentNode.classList.remove("focused")
      }
    })
  })

  // Add loading animation on form submit
  const forms = document.querySelectorAll("form")
  forms.forEach((form) => {
    form.addEventListener("submit", function () {
      const button = this.querySelector(".btn")
      button.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Processing...'
      button.disabled = true
    })
  })
})

// Add some visual feedback when clicking buttons
const buttons = document.querySelectorAll(".btn")
buttons.forEach((button) => {
  button.addEventListener("mousedown", function () {
    this.style.transform = "scale(0.95)"
  })

  button.addEventListener("mouseup", function () {
    this.style.transform = ""
  })

  button.addEventListener("mouseleave", function () {
    this.style.transform = ""
  })
})
